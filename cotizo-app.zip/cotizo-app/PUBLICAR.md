# Cómo publicar Cotizo (paso a paso)

Hazlo desde un ordenador: subir archivos y copiar claves es mucho más cómodo que desde el móvil.
Tiempo total: 2–3 horas la primera vez. Ve en este orden y marca cada paso.

## Fase 1 · Cuentas (30 min)
Crea cuenta en: **GitHub**, **Vercel**, **Supabase**, **Stripe**, **Anthropic** (console.anthropic.com) y un registrador de dominio (**Porkbun**, **Namecheap** o **Cloudflare**).
Compra el dominio (por ejemplo `cotizo.app`; unos 10–15 €/año).

> Importante sobre el alojamiento: el plan gratuito de Vercel (Hobby) está pensado para uso personal y no comercial. Cuando empieces a cobrar, pasa a Vercel Pro (unos 20 $/mes) o usa otro hosting que permita uso comercial. Confirma las condiciones vigentes en su web.

## Fase 2 · Base de datos y cuentas de usuario (Supabase, 15 min)
1. New project → elige región cercana a tus clientes y guarda la contraseña.
2. SQL Editor → pega todo `schema.sql` → Run. (Crea usuarios, historial y el almacén de currículums.)
3. Project Settings → API: copia **Project URL**, **anon key** y **service_role key** (secreta).
4. Authentication → URL Configuration:
   - Site URL: `https://TU-DOMINIO`
   - Redirect URLs: añade `https://TU-DOMINIO` y `https://TU-DOMINIO/**`
5. **Correo de acceso:** el envío de correos gratis de Supabase tiene un límite muy bajo (unos pocos por hora) y no sirve para producción. Crea una cuenta en **Resend** (gratis hasta 3.000 correos/mes), verifica tu dominio y pega los datos en Supabase → Authentication → SMTP Settings. Mientras tanto, el acceso con Google, Microsoft y Facebook no depende de esto.

## Fase 3 · Acceso con Google, Microsoft y Facebook (45 min)
Para los tres necesitas esta dirección de retorno (en Supabase → Authentication → Providers verás la tuya):
`https://TU-PROYECTO.supabase.co/auth/v1/callback`

**Google**
1. console.cloud.google.com → crea un proyecto.
2. APIs y servicios → Pantalla de consentimiento OAuth → tipo *Externo*. Pon nombre de la app, tu correo, el enlace a tu política de privacidad y a tus términos. Ámbitos: `email`, `profile`, `openid`.
3. Credenciales → Crear credenciales → ID de cliente OAuth → *Aplicación web*. En "URI de redireccionamiento autorizados" pega la dirección de retorno.
4. Copia *Client ID* y *Client secret* en Supabase → Providers → Google → Enable.
5. Pantalla de consentimiento → **Publicar aplicación** (si no, solo entrarán usuarios de prueba).

**Microsoft (aparece como "Azure" en Supabase)**
1. portal.azure.com → Microsoft Entra ID → Registros de aplicaciones → Nuevo registro.
2. Tipos de cuenta: *Cuentas en cualquier directorio de la organización y cuentas personales de Microsoft*.
3. URI de redirección (Web): la dirección de retorno.
4. Copia el *Id. de aplicación (cliente)*. En Certificados y secretos crea un secreto y copia su **Valor** (solo se ve una vez).
5. En Supabase → Providers → Azure: pega ID y secreto. Deja la URL de tenant en blanco para aceptar cuentas personales y de trabajo.

**Facebook**
1. developers.facebook.com → Crear app → caso de uso *Autenticar y solicitar datos a usuarios* (Facebook Login).
2. Configuración → Básica: añade tu dominio, la URL de política de privacidad (`https://TU-DOMINIO/privacidad.html`) y de términos.
3. Facebook Login → Configuración → *URI de redireccionamiento de OAuth válidos*: la dirección de retorno.
4. Copia *ID de la app* y *Clave secreta* en Supabase → Providers → Facebook.
5. Arriba, cambia la app de *Desarrollo* a **En vivo**. Si no, solo podrás entrar tú.

## Fase 4 · Pagos (Stripe, 30 min)
1. En **modo prueba**: crea los productos *Pro* (12 $/mes y 115 $/año) y *Agencia* (29 $/mes y 278 $/año). Copia los 4 identificadores `price_...`.
2. Developers → API keys → copia la *Secret key*.
3. Settings → Billing → Customer portal → Activar (cancelar y cambiar de plan).
4. El webhook lo creas después de publicar (Fase 6).

## Fase 5 · Subir el código y publicar (30 min)
1. Descomprime `cotizo-app.zip`.
2. **Antes de subir**, edita en `public/privacidad.html` y `public/terminos.html` los textos entre corchetes (`[NOMBRE LEGAL]`, `[EMAIL]`, `[PAÍS]`, `[FECHA]`) y borra el aviso gris. En `public/index.html` cambia `soporte@tudominio.com` por tu correo real. Pide a un abogado que revise los textos legales.
3. GitHub → New repository (privado) → *uploading an existing file* → arrastra **el contenido** de la carpeta `cotizo-app` (no el zip) → Commit.
4. Vercel → Add New → Project → importa el repositorio.
5. En *Environment Variables* añade todas las de `.env.example` con tus claves (de Supabase, Anthropic y Stripe).
6. Deploy. Cuando termine verás una dirección `tu-proyecto.vercel.app`.
7. Vercel → Settings → Domains → añade tu dominio y copia en tu registrador los registros DNS que Vercel te indique. Tarda de minutos a unas horas.
8. Cuando el dominio funcione, pon `SITE_URL=https://TU-DOMINIO` en Vercel y haz Redeploy.

## Fase 6 · Conectar el webhook de Stripe (10 min)
Stripe → Developers → Webhooks → Add endpoint:
- URL: `https://TU-DOMINIO/api/webhook`
- Eventos: `checkout.session.completed`, `customer.subscription.created`, `customer.subscription.updated`, `customer.subscription.deleted`
- Copia el *Signing secret* (`whsec_...`) en la variable `STRIPE_WEBHOOK_SECRET` de Vercel y haz Redeploy.

## Fase 7 · Pruebas antes de abrir (30 min)
Marca todas:
- [ ] Entras con Google, con Microsoft, con Facebook y con correo.
- [ ] Creas una propuesta y aparece en *Cuenta → Propuestas*.
- [ ] Subes un PDF de currículum y aparece el enlace en "Quién soy" de la propuesta.
- [ ] La cuarta propuesta gratis del mes te lleva a los planes.
- [ ] Pagas con la tarjeta de prueba `4242 4242 4242 4242` y tu plan pasa a Pro (sin marca de agua).
- [ ] Cancelas desde *Cuenta → Plan → Gestionar suscripción*.
- [ ] La web se ve bien en tu móvil y en un ordenador.

## Fase 8 · Pasar a cobros reales
1. Stripe → activa tu cuenta (datos del negocio y cuenta bancaria).
2. Repite en **modo real** los productos y precios; sustituye `STRIPE_SECRET_KEY` y los 4 `price_...` en Vercel; crea el webhook en modo real y actualiza `STRIPE_WEBHOOK_SECRET`.
3. Redeploy y haz un pago real pequeño con tu tarjeta (luego lo reembolsas).

## Fase 9 · Que empiece a usarse
1. Mide desde el día 1: instala **Plausible** o **Vercel Analytics** (visitas) y revisa en Supabase → Authentication → Users los registros.
2. Publica tu enlace en tu perfil de LinkedIn, Instagram y en la bio de TikTok.
3. Sigue el plan de captación del `README.md`: 30 mensajes directos al día, una publicación diaria en grupos y 5 llamadas con usuarios en las primeras 2 semanas.
4. Añade el sitio a **Google Search Console** para que empiece a aparecer en buscadores.
5. Responde todos los correos de soporte en menos de 24 horas: al principio es tu mejor ventaja.

## Costes mensuales aproximados
| Concepto | Coste |
|---|---|
| Dominio | ~1 € |
| Supabase | 0 € al inicio |
| Vercel | 0 € para probar; unos 20 $ al cobrar |
| Resend | 0 € hasta 3.000 correos |
| Stripe | ~2,9 % + 0,30 $ por cobro (varía por país) |
| IA (Anthropic) | ~1–3 céntimos por propuesta |
