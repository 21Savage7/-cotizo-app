-- Pega esto en Supabase > SQL Editor > Run. Se puede ejecutar varias veces sin problema.

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  plan text not null default 'free',
  stripe_customer_id text,
  used_month int not null default 0,
  month text,
  created_at timestamptz not null default now()
);
alter table public.profiles add column if not exists display_name text;
alter table public.profiles add column if not exists headline text;
alter table public.profiles add column if not exists bio text;
alter table public.profiles add column if not exists contact text;
alter table public.profiles add column if not exists cv_url text;

alter table public.profiles enable row level security;
drop policy if exists "leer propio perfil" on public.profiles;
create policy "leer propio perfil" on public.profiles for select using (auth.uid() = id);

-- Historial de propuestas (solo accesible desde el servidor)
create table if not exists public.proposals (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text,
  client text,
  input jsonb,
  data jsonb,
  created_at timestamptz not null default now()
);
create index if not exists proposals_user_idx on public.proposals (user_id, created_at desc);
alter table public.proposals enable row level security;

-- Perfil automático en cada registro (cada registro es un lead)
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, email) values (new.id, new.email)
  on conflict (id) do nothing;
  return new;
end; $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- Almacenamiento de currículums (PDF, máx. 5 MB, carpeta propia de cada usuario)
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('cvs', 'cvs', true, 5242880, array['application/pdf'])
on conflict (id) do update set file_size_limit = 5242880, allowed_mime_types = array['application/pdf'];

drop policy if exists "cv subir propio" on storage.objects;
create policy "cv subir propio" on storage.objects for insert to authenticated
  with check (bucket_id = 'cvs' and (storage.foldername(name))[1] = auth.uid()::text);
drop policy if exists "cv actualizar propio" on storage.objects;
create policy "cv actualizar propio" on storage.objects for update to authenticated
  using (bucket_id = 'cvs' and (storage.foldername(name))[1] = auth.uid()::text)
  with check (bucket_id = 'cvs' and (storage.foldername(name))[1] = auth.uid()::text);
drop policy if exists "cv borrar propio" on storage.objects;
create policy "cv borrar propio" on storage.objects for delete to authenticated
  using (bucket_id = 'cvs' and (storage.foldername(name))[1] = auth.uid()::text);
