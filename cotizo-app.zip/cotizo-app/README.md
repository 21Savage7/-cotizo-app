# Cotizo

Generador de propuestas comerciales con IA para freelancers. Incluye acceso con Google, Microsoft, Facebook o correo, perfil profesional con currículum en PDF, historial de propuestas, planes de pago con Stripe y 7 días de prueba.

## Qué hay en la carpeta
- `public/` → la web (index, privacidad, términos)
- `api/` → el servidor (generar propuestas, perfil, historial, pagos y webhook)
- `schema.sql` → la base de datos (se pega en Supabase)
- `.env.example` → las claves que debes configurar
- **`PUBLICAR.md` → guía completa para publicarla paso a paso**

## PARTE 1 · Publicar
Sigue **`PUBLICAR.md`**.

---

## PARTE 2 · Captar tus primeros 50 clientes

Cada registro en Supabase (Authentication → Users) es un lead con correo. El objetivo de los primeros 30 días no es ganar dinero: es conseguir **20 personas que usen Cotizo de verdad** y que te digan qué les falta.

### Dónde está tu cliente
Freelancers de diseño, desarrollo web, marketing, redacción, fotografía y reformas. Los encuentras en:
- Workana, Freelancer, Upwork, Fiverr: perfiles activos con servicios publicados.
- Grupos de Facebook y comunidades de Discord/Slack de freelancers en español.
- LinkedIn: busca "diseñador freelance", "desarrollador freelance", "consultor independiente".
- Reddit: r/freelance, r/Emprendedores, r/devsarg y similares (lee las normas antes de publicar).

### Mensajes listos (cámbialos a tu tono)

**Mensaje directo (30 al día):**
> Hola [nombre], vi tu perfil de [servicio]. Estoy probando una herramienta que escribe la propuesta completa (alcance, plazos y precio) en 30 segundos. ¿Te la enseño? Es gratis, solo busco opinión sincera.

**Publicación en grupos:**
> Ayer tardé 2 horas en una propuesta para un cliente. Hice una herramienta que la genera en 30 segundos a partir de una descripción corta. Busco 20 freelancers para probarla gratis y decirme qué mejorarían. Comenta "quiero" y te paso el enlace.

**Seguimiento (3 días después):**
> ¿Pudiste probar Cotizo? Si algo no te cuadró, dímelo y lo arreglo esta semana.

### Plan de 14 días
- **Días 1–3:** haz tu propia propuesta de ejemplo para 3 sectores y publícalas como capturas.
- **Días 4–10:** 30 mensajes directos al día + 1 publicación diaria en un grupo distinto.
- **Días 11–14:** habla por videollamada con 5 usuarios (15 min). Pregunta: "¿qué te frenó para pagar?".
- Ofrece a los 10 mejores usuarios 1 mes de Pro a cambio de un testimonio.

### Contenido que atrae
- Vídeo corto (15–30 s) en TikTok, Reels y Shorts: pantalla grabada de "descripción → propuesta lista". Repite con distintos oficios.
- Hilo en LinkedIn: "Cómo estructurar una propuesta que el cliente acepte", con Cotizo como herramienta final.
- Plantilla gratuita descargable a cambio del correo.

### Números que debes mirar cada semana
| Métrica | Objetivo inicial |
|---|---|
| Registros | 50 en 30 días |
| Registro → primera propuesta creada | más del 60% |
| Gratis → prueba de Pro | 5–10% |
| Prueba → pago | 40–50% |
| Cancelación mensual | menos del 8% |

Si la gente se registra pero no crea propuestas, falla el mensaje. Si crea propuestas pero no paga, falla el valor del plan Pro (prueba a ofrecer logo propio o plantillas por oficio).

### Siguientes mejoras (por orden)
1. Historial de propuestas guardadas.
2. Logo y colores propios en el PDF (el gancho del plan Pro).
3. Enlace público de la propuesta con aviso cuando el cliente la abre.
4. Correo automático al registrarse y a los 3 días sin uso.
