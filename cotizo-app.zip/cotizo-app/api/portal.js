const { admin, stripe, getUser, getProfile, siteUrl } = require('../lib/clients');

module.exports = async (req, res) => {
  const user = await getUser(req);
  if (!user) return res.status(401).json({ error: 'Inicia sesión.' });
  const p = await getProfile(admin(), user);
  if (!p.stripe_customer_id) return res.status(400).json({ error: 'Aún no tienes una suscripción.' });
  try {
    const portal = await stripe().billingPortal.sessions.create({
      customer: p.stripe_customer_id, return_url: siteUrl(req),
    });
    res.status(200).json({ url: portal.url });
  } catch (e) {
    console.error('portal error', e.message);
    res.status(500).json({ error: 'No pudimos abrir tu cuenta de pagos.' });
  }
};
