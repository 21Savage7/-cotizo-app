const { admin, getUser, getProfile } = require('../lib/clients');

module.exports = async (req, res) => {
  const user = await getUser(req);
  if (!user) return res.status(401).json({ error: 'Inicia sesión.' });
  const p = await getProfile(admin(), user);
  res.status(200).json({
    email: user.email,
    plan: p.plan,
    used: p.used_month,
    profile: {
      display_name: p.display_name || '',
      headline: p.headline || '',
      bio: p.bio || '',
      contact: p.contact || '',
      cv_url: p.cv_url || '',
    },
  });
};
