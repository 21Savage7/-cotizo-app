const { admin, stripe } = require('../lib/clients');

// Stripe necesita el cuerpo sin procesar para verificar la firma
module.exports.config = { api: { bodyParser: false } };

function raw(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    req.on('data', c => chunks.push(c));
    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}

const ACTIVE = ['active', 'trialing', 'past_due'];

module.exports = async (req, res) => {
  if (req.method !== 'POST') return res.status(405).end();
  const s = stripe();
  let event;
  try {
    event = s.webhooks.constructEvent(await raw(req), req.headers['stripe-signature'], process.env.STRIPE_WEBHOOK_SECRET);
  } catch (e) {
    console.error('firma inválida', e.message);
    return res.status(400).send('Firma inválida');
  }

  const sb = admin();
  try {
    if (event.type === 'checkout.session.completed') {
      const session = event.data.object;
      const sub = await s.subscriptions.retrieve(session.subscription);
      await sb.from('profiles').update({
        plan: sub.metadata.plan || 'pro',
        stripe_customer_id: session.customer,
      }).eq('id', session.client_reference_id);
    }
    if (event.type === 'customer.subscription.updated' || event.type === 'customer.subscription.created') {
      const sub = event.data.object;
      const plan = ACTIVE.includes(sub.status) ? (sub.metadata.plan || 'pro') : 'free';
      await sb.from('profiles').update({ plan }).eq('stripe_customer_id', sub.customer);
    }
    if (event.type === 'customer.subscription.deleted') {
      await sb.from('profiles').update({ plan: 'free' }).eq('stripe_customer_id', event.data.object.customer);
    }
    res.status(200).json({ received: true });
  } catch (e) {
    console.error('webhook error', e.message);
    res.status(500).send('Error');
  }
};
