const { admin, stripe, getUser, getProfile, siteUrl } = require('../lib/clients');

const PRICES = () => ({
  pro: { month: process.env.STRIPE_PRICE_PRO_MONTH, year: process.env.STRIPE_PRICE_PRO_YEAR },
  agency: { month: process.env.STRIPE_PRICE_AGENCY_MONTH, year: process.env.STRIPE_PRICE_AGENCY_YEAR },
});

module.exports = async (req, res) => {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Método no permitido.' });
  const user = await getUser(req);
  if (!user) return res.status(401).json({ error: 'Inicia sesión.' });

  const { plan, interval } = req.body || {};
  const price = (PRICES()[plan] || {})[interval];
  if (!price) return res.status(400).json({ error: 'Plan no válido.' });

  const p = await getProfile(admin(), user);
  const s = stripe();
  const base = siteUrl(req);

  try {
    // Si ya paga, lo mandamos al portal para cambiar de plan
    if (p.plan !== 'free' && p.stripe_customer_id) {
      const portal = await s.billingPortal.sessions.create({ customer: p.stripe_customer_id, return_url: base });
      return res.status(200).json({ url: portal.url });
    }
    const session = await s.checkout.sessions.create({
      mode: 'subscription',
      line_items: [{ price, quantity: 1 }],
      customer: p.stripe_customer_id || undefined,
      customer_email: p.stripe_customer_id ? undefined : user.email,
      client_reference_id: user.id,
      allow_promotion_codes: true,
      subscription_data: { trial_period_days: 7, metadata: { plan, user_id: user.id } },
      success_url: base + '/?checkout=success',
      cancel_url: base + '/#precios',
    });
    return res.status(200).json({ url: session.url });
  } catch (e) {
    console.error('checkout error', e.message);
    return res.status(500).json({ error: 'No pudimos abrir el pago. Inténtalo de nuevo.' });
  }
};
