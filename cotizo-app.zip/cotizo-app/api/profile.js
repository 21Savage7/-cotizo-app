const { admin, getUser } = require('../lib/clients');

const clean = (v, max) => String(v || '').replace(/[\u0000-\u001f]+/g, ' ').trim().slice(0, max);

module.exports = async (req, res) => {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Método no permitido.' });
  const user = await getUser(req);
  if (!user) return res.status(401).json({ error: 'Inicia sesión.' });

  const b = req.body || {};
  // El currículum solo puede apuntar a la carpeta del propio usuario en nuestro almacenamiento
  const prefix = `${process.env.SUPABASE_URL}/storage/v1/object/public/cvs/${user.id}/`;
  let cv = String(b.cv_url || '').trim();
  if (cv && !cv.startsWith(prefix)) cv = '';

  const update = {
    display_name: clean(b.display_name, 80),
    headline: clean(b.headline, 120),
    bio: clean(b.bio, 600),
    contact: clean(b.contact, 160),
    cv_url: cv.slice(0, 400),
  };
  const { error } = await admin().from('profiles').update(update).eq('id', user.id);
  if (error) return res.status(500).json({ error: 'No pudimos guardar tu perfil.' });
  res.status(200).json({ profile: update });
};
