const { admin, getUser } = require('../lib/clients');

module.exports = async (req, res) => {
  const user = await getUser(req);
  if (!user) return res.status(401).json({ error: 'Inicia sesión.' });
  const sb = admin();
  const id = req.query && req.query.id;

  if (req.method === 'GET' && !id) {
    const { data, error } = await sb.from('proposals')
      .select('id,title,client,created_at').eq('user_id', user.id)
      .order('created_at', { ascending: false }).limit(50);
    if (error) return res.status(500).json({ error: 'No pudimos cargar tu historial.' });
    return res.status(200).json({ items: data });
  }
  if (req.method === 'GET' && id) {
    const { data } = await sb.from('proposals').select('id,input,data').eq('id', id).eq('user_id', user.id).maybeSingle();
    if (!data) return res.status(404).json({ error: 'No encontramos esa propuesta.' });
    return res.status(200).json({ item: data });
  }
  if (req.method === 'DELETE' && id) {
    await sb.from('proposals').delete().eq('id', id).eq('user_id', user.id);
    return res.status(200).json({ ok: true });
  }
  res.status(405).json({ error: 'Método no permitido.' });
};
